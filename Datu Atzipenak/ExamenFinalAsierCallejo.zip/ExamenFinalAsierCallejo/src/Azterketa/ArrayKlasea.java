package Azterketa;

import java.util.ArrayList;
import com.thoughtworks.xstream.annotations.XStreamAlias;



public class ArrayKlasea {
	
	@XStreamAlias("Konpositoreak")
	private ArrayList<Konpositoreak> konpoArray;

	@XStreamAlias("Estiloak")
	private ArrayList<Estiloak> estiArray;
		
	@XStreamAlias("Obrak")
	private ArrayList<Obrak> obraArray;
	
	public ArrayKlasea(ArrayList<Konpositoreak> konpoArray, ArrayList<Estiloak> estiArray, ArrayList<Obrak> obraArray) {
		super();
		this.konpoArray= konpoArray;
		this.estiArray = estiArray;
		this.obraArray= obraArray;
	}
	
	
	
	

}
