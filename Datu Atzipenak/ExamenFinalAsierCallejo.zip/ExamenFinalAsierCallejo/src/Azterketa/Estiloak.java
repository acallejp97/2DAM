package Azterketa;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;

@XStreamAlias("Estiloak")
public class Estiloak {
	
	@XStreamAsAttribute private int ID;
	private String izena;
	
	public Estiloak(int id, String estiloa) {
		super();
		ID = id;
		this.izena = estiloa;
	}

	public Estiloak() {
		
	}
	
	public int getID() {
		return ID;
	}
	
	public void setID(int iD) {
		ID = iD;
	}
	

	public String getEstiloa() {
		return izena;
	}


	public void setEstiloa(String estiloa) {
		izena = estiloa;
	}
	
}