package Azterketa;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Konexion{
	public static Connection konekzioa = null;
	
	
	
	public static Connection getKonekzioa() {
		return konekzioa;
	}

	public static void setKonekzioa(Connection konekzioa) {
		Konexion.konekzioa = konekzioa;
	}

	public Konexion() {
		
		String datubasea = "MusikaKlasikoa";
		String login = "root";
		String password = "admin";
		String host = "localhost";
		String url = "jdbc:mariadb://" + host + "/" + datubasea;
		
		// Erregistratu driverra

		try {
			Class.forName("org.mariadb.jdbc.Driver");

		} catch (ClassNotFoundException e) {
			System.err.println("Errorea" + "com.mysql.jdbc.Driver");
			System.err.println(e.toString());
		}try {
			konekzioa = (Connection) DriverManager.getConnection(url, login,password);
			
			System.out.println("Konexioa ondo burutu da !!!!");
		} catch (SQLException sqle) {
		
			System.err.println("Akats larria!!! Konexio1 ez da burutu");
			System.err.println(sqle.toString());
		}
		
			
	}

}
