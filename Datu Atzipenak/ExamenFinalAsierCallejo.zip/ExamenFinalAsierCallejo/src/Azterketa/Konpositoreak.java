package Azterketa;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;

@XStreamAlias("Konpositorea")
public class Konpositoreak {

	@XStreamAsAttribute private int ID;
	private String izena;
	private int jaio;
	private int hil;

	public Konpositoreak(int id, String izena, int jaio, int hil) {
		super();
		ID = id;
		this.izena= izena;
		this.jaio = jaio;
		this.hil = hil;
	}
 
	public Konpositoreak() {
		
	}

	public int getId() {
		return ID;
	}

	public void setId(int id) {
		this.ID = id;
	}

	public String getIzena() {
		return izena;
	}

	public void setIzena(String izena) {
		this.izena = izena;
	}

	public int getJaio() {
		return jaio;
	}

	public void setJaio(int jaio) {
		this.jaio = jaio;
	}

	public int getHil() {
		return hil;
	}

	public void setHil(int hil) {
		this.hil = hil;
	}

}

