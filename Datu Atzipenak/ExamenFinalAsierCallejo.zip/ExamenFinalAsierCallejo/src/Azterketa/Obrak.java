package Azterketa;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;

@XStreamAlias("Musika")
public class Obrak {


	@XStreamAsAttribute private int ID;
	@XStreamAsAttribute private int kon;
	@XStreamAsAttribute private int est;
	private String titulua;
	private String deskribapena;
	
	public Obrak(int id, String desc, int kon, int est, String titulua) {
		super();
		ID=id;
		this.kon=kon;
		this.est=est;
		this.titulua=titulua;
		deskribapena=desc;
		
	}
	public Obrak() {
		
	}
	public int getID() {
		return ID;
	}
	public void setID(int iD) {
		ID = iD;
	}
	public int getKon() {
		return kon;
	}
	public void setKon(int kon) {
		this.kon = kon;
	}
	public int getEst() {
		return est;
	}
	public void setEst(int est) {
		this.est = est;
	}
	public String getDeskribapena() {
		return deskribapena;
	}
	public void setDeskribapena(String deskribapena) {
		this.deskribapena = deskribapena;
	}
	public String getTitulua() {
		return titulua;
	}
	public void setTitulua(String titulua) {
		this.titulua = titulua;
	}
	
	
	
}