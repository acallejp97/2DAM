package Azterketa;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;


import com.thoughtworks.xstream.XStream;

public class main {

	private static ArrayList<Konpositoreak> konpo = new ArrayList<Konpositoreak>();
	private static ArrayList<Estiloak> esti = new ArrayList<Estiloak>();
	private static ArrayList<Obrak> obra = new ArrayList<Obrak>();

	public static void main(String[] args) {
		hartuKonpositoreak();
		hartuEstiloak();
		hartuObrak();
		XStream xstream = new XStream();
		ArrayKlasea KlasikaOberenak = new ArrayKlasea(konpo, esti, obra);
		xstream.alias("KlasikaHoberenak", ArrayKlasea.class);
		xstream.processAnnotations(ArrayKlasea.class);
		xstream.alias("Konpositorea", Konpositoreak.class);
		xstream.processAnnotations(Konpositoreak.class);
		xstream.alias("Estiloa", Estiloak.class);
		xstream.processAnnotations(Estiloak.class);
		xstream.alias("Obra", Obrak.class);
		xstream.processAnnotations(Obrak.class);
		String xml = xstream.toXML(KlasikaOberenak);
		System.out.println(xml);
		try (FileWriter fitxategiaXML = new FileWriter(new File("MusikaKlasikoa.xml"))) {
			String header = "<?xml version=\"1.0\" encoding=\"" + "UTF-8" + "\"?>\n";
			String emaitza = header + xml;
			fitxategiaXML.write(emaitza);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		// imprimatu();
		imprimatu2();
	}

	public static void hartuKonpositoreak() {
		try {
			Konexion kon = new Konexion();
			Connection con = kon.getKonekzioa();
			String sql = "SELECT * FROM Konpositorea";
			Statement sententzia;
			sententzia = con.createStatement();
			ResultSet rs = sententzia.executeQuery(sql);
			while (rs.next()) {
				Konpositoreak konp = new Konpositoreak();
				konp.setId(rs.getInt(1));
				konp.setIzena(rs.getString(2));
				konp.setJaio(rs.getInt(3));
				konp.setHil(rs.getInt(4));
				konpo.add(konp);
			}
			sententzia.close();
			rs.close();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void hartuEstiloak() {
		try {
			Konexion kon = new Konexion();
			Connection con = kon.getKonekzioa();
			String sql = "SELECT * FROM Estiloa";
			Statement sententzia;
			sententzia = con.createStatement();
			ResultSet rs = sententzia.executeQuery(sql);
			while (rs.next()) {
				Estiloak est = new Estiloak();
				est.setID(rs.getInt(1));
				est.setEstiloa(rs.getString(2));
				esti.add(est);
			}
			sententzia.close();
			rs.close();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void hartuObrak() {
		try {
			Konexion kon = new Konexion();
			Connection con = kon.getKonekzioa();
			String sql = "SELECT * FROM Musika";
			Statement sententzia;
			sententzia = con.createStatement();
			ResultSet rs = sententzia.executeQuery(sql);
			while (rs.next()) {
				Obrak obr = new Obrak();
				obr.setID(rs.getInt(1));
				obr.setDeskribapena(rs.getString(2));
				obr.setKon(rs.getInt(3));
				obr.setEst(rs.getInt(4));
				obr.setTitulua(rs.getString(5));
				obra.add(obr);
			}
			sententzia.close();
			rs.close();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void imprimatu2() {

		System.out.println("Zerrendatu WOLFGANG AMADEUS MOZART musikariak sortutako OPERA estiloko obrak");
		try {
			Konexion kon = new Konexion();
			Connection con = kon.getKonekzioa();
			String sql = "SELECT Izena FROM Musika WHERE konpositorea = \n"
					+ "	(select id from Konpositorea where Izena like 'Wolfgang Amadeus MOZART') \n"
					+ "	AND estiloa = (select id from Estiloa where Izena like 'Opera');";
			Statement sententzia;
			sententzia = con.createStatement();
			ResultSet rs = sententzia.executeQuery(sql);
			while (rs.next()) {
				System.out.println(rs.getString(1));
			}
			sententzia.close();
			rs.close();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void imprimatu() {
		System.out.println("zerrendatu bi zutabeko...");
		try {
			Konexion kon = new Konexion();
			Connection con = kon.getKonekzioa();
			String sql = "SELECT Izena FROM Musika WHERE konpositorea = \n"
					+ "	(select id from Konpositorea where Izena like 'Wolfgang Amadeus MOZART') \n"
					+ "	AND estiloa = (select id from Estiloa where Izena like 'Opera');";
			Statement sententzia;
			sententzia = con.createStatement();
			ResultSet rs = sententzia.executeQuery(sql);
			while (rs.next()) {
				System.out.println(rs.getString(1));
			}

			sententzia.close();
			rs.close();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
