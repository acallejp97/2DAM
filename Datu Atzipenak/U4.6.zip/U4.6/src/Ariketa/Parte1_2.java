package Ariketa;

import org.w3c.dom.*;
import org.xml.sax.SAXException;
import javax.xml.parsers.*;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathFactory;

import java.io.*;

public class Parte1_2 {
	static NodeList nList;

	public static void main(String[] args) {
		/*
		 * <book category="COOKING" isbn="A45"> <title lang="en">Everyday
		 * Italian</title> <author>Giada De Laurentiis</author> <year>2005</year>
		 * <price>30.00</price> <available-in> <shop>London</shop>
		 * <shop>Manchester</shop> <internet>http://www.thebookstore.com</internet>
		 * </available-in> </book>
		 */
		try {

			File fichero;
			File fitxero;
			DocumentBuilderFactory dbf;
			DocumentBuilder dBuilder;
			Document doc;
			Document gorde = null;

			// DOM erabiltzeko behar diren osagaiak
			fichero = new File("Bookstore.xml");
			dbf = DocumentBuilderFactory.newInstance();
			dBuilder = dbf.newDocumentBuilder();
			doc = dBuilder.parse(fichero);
			doc.getDocumentElement().normalize();
			nList = doc.getElementsByTagName("book");

			// XML-a irakurri egiten du
			LiburuakZerrendatu(doc);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public static void LiburuakZerrendatu(Document doc) {
		try {
			XPath xpath;
			XPathFactory xpathfactory = XPathFactory.newInstance();
			xpath = xpathfactory.newXPath();
			XPathExpression expr = xpath.compile("//bookstore/book/title/text()");
			Object result = expr.evaluate(doc, XPathConstants.NODESET);
			NodeList nodes = (NodeList) result;
			XPathExpression expre = xpath.compile("//bookstore/book/price/text()");
			Object resulte = expre.evaluate(doc, XPathConstants.NODESET);
			NodeList nodese = (NodeList) resulte;
			System.out.println("LIBURUAK"
					+ "\n============================================");
			for (int i = 0; i < nodese.getLength(); i++) {
				System.out.println(nodes.item(i).getNodeValue()+"("+nodese.item(i).getNodeValue()+")");

			}

		} catch (Exception ex) {
			System.out.print("Errore: ");
			ex.printStackTrace();
		}
	}
}
