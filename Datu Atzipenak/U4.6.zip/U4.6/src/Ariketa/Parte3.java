package Ariketa;

import org.w3c.dom.*;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.StringTokenizer;

import javax.xml.parsers.*;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

public class Parte3 {
	static NodeList nList;

	public static void main(String[] args) {
		/*
		 * <book category="COOKING" isbn="A45"> <title lang="en">Everyday
		 * Italian</title> <author>Giada De Laurentiis</author> <year>2005</year>
		 * <price>30.00</price> <available-in> <shop>London</shop>
		 * <shop>Manchester</shop> <internet>http://www.thebookstore.com</internet>
		 * </available-in> </book>
		 */
		try {

			File fichero;
			DocumentBuilderFactory dbf;
			DocumentBuilder dBuilder;
			Document doc;

			// DOM erabiltzeko behar diren osagaiak
			fichero = new File("Bookstore.xml");
			dbf = DocumentBuilderFactory.newInstance();
			dBuilder = dbf.newDocumentBuilder();
			doc = dBuilder.parse(fichero);
			doc.getDocumentElement().normalize();
			nList = doc.getElementsByTagName("book");

			LiburuakZerrendatu(doc);
			System.out.println();
			ArrayList<String> ar = LiburuaIrakurri("liburuBerria.txt");
			System.out.println();
			LiburuaGehitu(doc, ar, "Bookstore.xml");
			System.out.println();
			inprimatuKategoriak(doc, "WEB", "London");
			System.out.println();
			inprimatuKategoriakDenda(doc);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public static void inprimatuKategoriak(Document doc, String kategoria, String hiria) {
		try {
			XPath xpath;
			XPathFactory xpathfactory = XPathFactory.newInstance();
			xpath = xpathfactory.newXPath();
			// title
			XPathExpression expr = xpath.compile(
					"//bookstore/book[@category='" + kategoria + "'][available-in/shop='" + hiria + "']/title/text()");
			Object result = expr.evaluate(doc, XPathConstants.NODESET);
			NodeList nodes = (NodeList) result;
			// isbn
			XPathExpression expre = xpath.compile(
					"//bookstore/book[@category='" + kategoria + "'][available-in/shop='" + hiria + "']/@isbn");
			Object resulte = expre.evaluate(doc, XPathConstants.NODESET);
			NodeList nodese = (NodeList) resulte;
			// year
			XPathExpression expri = xpath.compile(
					"//bookstore/book[@category='" + kategoria + "'][available-in/shop='" + hiria + "']/year/text()");
			Object resulti = expri.evaluate(doc, XPathConstants.NODESET);
			NodeList nodesi = (NodeList) resulti;
			String formatoa = "%1$-15s%2$-17S%3$-25S%n";
			System.out.println("--------------------------------------");
			for (int i = 0; i < nodes.getLength(); i++) {
				System.out.printf(formatoa, nodes.item(i).getNodeValue(), nodese.item(i).getNodeValue(),
						nodesi.item(i).getNodeValue());
			}

		} catch (XPathExpressionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public static ArrayList<String> addUnique(ArrayList<String> lista, String elemento) {

		if (!lista.contains(elemento))
			lista.add(elemento);
		return lista;
	}

	public static void inprimatuKategoriakDenda(Document doc) {
		int children, coocking, web, guztira;
		XPath xpath;
		XPathFactory xpathfactory = XPathFactory.newInstance();
		xpath = xpathfactory.newXPath();
		XPathExpression expr;
		ArrayList<String> kategoriak = new ArrayList<String>();
		ArrayList<String> denda = new ArrayList<String>();
		try {
			expr = xpath.compile("//bookstore/book/@category");
			Object result = expr.evaluate(doc, XPathConstants.NODESET);
			NodeList nodes = (NodeList) result;
			for (int i = 0; i < nodes.getLength(); i++) {
				kategoriak = addUnique(kategoriak, nodes.item(i).getNodeValue());

			}
			expr = xpath.compile("//bookstore/book/avaliable-in/shop/text()");
			result = expr.evaluate(doc, XPathConstants.NODESET);
			nodes = (NodeList) result;
			for (int i = 0; i < nodes.getLength(); i++) {
				denda = addUnique(denda, nodes.item(i).getNodeValue());

			}
			System.out.println("LIBURU KOPURUA KATEGORIAKA ETA DENDAKA");
			System.out.println("====================================================================");

			// String goiburua="\t\t";
			System.out.println();

			for (int i = 0; i < kategoriak.size(); i++) {
				if (i == 0)
					System.out.printf("%20s", kategoriak.get(i));
				else
					System.out.printf("%10s", kategoriak.get(i));
			}

			System.out.printf("%10s%n", "GUZTIRA");
			for (int i = 0; i <= (kategoriak.size() + 1); i++) {
				System.out.print("-----------");
			}
			System.out.println();

			for (int i = 0; i < denda.size(); i++) {
				int Guztira = 0;
				System.out.printf("%-10s", denda.get(i));
				for (int j = 0; j < kategoriak.size(); j++) {
					NodeList Liburuak = (NodeList) XPathFactory
							.newInstance().newXPath().compile("//book[@category='" + kategoriak.get(j)
									+ "'][./available-in/shop='" + denda.get(i) + "']")
							.evaluate(doc, XPathConstants.NODESET);
					int kopurua = Liburuak.getLength();
					Guztira += kopurua;
					System.out.printf("%10d", kopurua);
				}
				System.out.printf("%10d%n", Guztira);
			}

		} catch (XPathExpressionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public static void LiburuaGehitu(Document doc, ArrayList<String> liburuDatuak, String XMLfitxategia) {

		try {

			Element aita = doc.createElement("book");
			aita.setAttribute("category", liburuDatuak.get(0));
			aita.setAttribute("isbn", liburuDatuak.get(1));

			Element semea = doc.createElement("title");
			Text text = doc.createTextNode(liburuDatuak.get(2));
			semea.appendChild(text);
			semea.setAttribute("lang", liburuDatuak.get(3));
			aita.appendChild(semea);

			semea = doc.createElement("author");
			text = doc.createTextNode(liburuDatuak.get(4));
			semea.appendChild(text);
			aita.appendChild(semea);

			semea = doc.createElement("year");
			text = doc.createTextNode(liburuDatuak.get(5));
			semea.appendChild(text);
			aita.appendChild(semea);

			semea = doc.createElement("price");
			text = doc.createTextNode(liburuDatuak.get(6));
			semea.appendChild(text);
			aita.appendChild(semea);

			semea = doc.createElement("available-in");
			Element hiloba = doc.createElement("shop");
			text = doc.createTextNode(liburuDatuak.get(7));
			hiloba.appendChild(text);
			semea.appendChild(hiloba);
			aita.appendChild(semea);

			Element aitona = doc.getDocumentElement();
			aitona.appendChild(aita);

			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer;
			transformer = transformerFactory.newTransformer();
			DOMSource source = new DOMSource(doc);
			StreamResult result = new StreamResult(new File(XMLfitxategia));
			transformer.setOutputProperty(OutputKeys.INDENT, "yes");
			transformer.transform(source, result);

		} catch (TransformerConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (TransformerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public static ArrayList<String> LiburuaIrakurri(String fitxategia) {
		ArrayList<String> zerrenda = new ArrayList<String>();
		try (BufferedReader br = new BufferedReader(new FileReader(fitxategia))) {
			String lerroa;
			while ((lerroa = br.readLine()) != null) {
				StringTokenizer st = new StringTokenizer(lerroa, ":");
				st.nextToken();

				zerrenda.add(st.nextToken());
			}

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		for (int i = 0; i < zerrenda.size(); i++) {
			System.out.println(zerrenda.get(i));

		}
		return zerrenda;

	}

	public static void LiburuakZerrendatu(Document doc) {
		try {
			XPath xpath;
			XPathFactory xpathfactory = XPathFactory.newInstance();
			xpath = xpathfactory.newXPath();
			XPathExpression expr = xpath.compile("//bookstore/book/title/text()");
			Object result = expr.evaluate(doc, XPathConstants.NODESET);
			NodeList nodes = (NodeList) result;
			XPathExpression expre = xpath.compile("//bookstore/book/price/text()");
			Object resulte = expre.evaluate(doc, XPathConstants.NODESET);
			NodeList nodese = (NodeList) resulte;
			for (int i = 0; i < nodese.getLength(); i++) {
				System.out.println(nodes.item(i).getNodeValue() + "(" + nodese.item(i).getNodeValue() + ")");

			}

		} catch (Exception ex) {
			System.out.print("Errore: ");
			ex.printStackTrace();
		}

	}

}