﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


public partial class MultipleDateSelection : System.Web.UI.Page
{
    public List<DateTime> MultipleSelectedDates
    {
        get
        {
            if (ViewState["AAA"] == null)  ViewState["AAA"] = new List<DateTime>();
                return (List<DateTime>)ViewState["AAA"];   
        }
        set
        {
            //ViewState["AAA"] = value;
        }
    }

    protected void Calendar1_PreRender(object sender, EventArgs e)
    {
        
        Calendar1.SelectedDates.Clear();

        // Se tiene que poner porque cada vez que pulsamos un dia se vuelve a dibujar el calendario
        foreach (DateTime dt in MultipleSelectedDates)
        {
            Calendar1.SelectedDates.Add(dt);
        }
    }
    protected void Calendar1_SelectionChanged(object sender, EventArgs e)
    {

        if (MultipleSelectedDates.Contains(Calendar1.SelectedDate))
        {
            MultipleSelectedDates.Remove(Calendar1.SelectedDate);
        }
        else
        {
            MultipleSelectedDates.Add(Calendar1.SelectedDate);
        }
        
        ViewState["AAA"] = MultipleSelectedDates;
    }

   


    protected void btnGetSelectedDate_Click(object sender, EventArgs e)
    {
        lblDate.Text = "";
        foreach (DateTime dt in MultipleSelectedDates)
        {
            lblDate.Text = lblDate.Text + " <br/> " + dt.ToString("dd/MM/yyyy");
        }
    }
}