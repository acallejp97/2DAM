﻿
Partial Class Defaultvb
    Inherits System.Web.UI.Page

    Dim sino As Boolean = False
    

    Protected Sub Calendar1_PreRender(sender As Object, e As System.EventArgs) Handles Calendar1.PreRender
        Calendar1.SelectedDates.Clear()
        ' Se tiene que poner porque cada vez que pulsamos 
        'un dia se vuelve a dibujar el calendario

        For Each dt In Session("AAA")
            Calendar1.SelectedDates.Add(dt)
        Next
      
    End Sub

    Protected Sub Calendar1_SelectionChanged(sender As Object, e As System.EventArgs) Handles Calendar1.SelectionChanged
        'SE EJECUTA DOS VECES  AL PULSAR UN DIA
        'LA PRIMERA VEZ SE GUARDA Y LA SEGUNDA LO BORRA, para evitarlo utilizo la variable sino.
        If sino = False Then
            Dim MultipleSelectedDates As New List(Of Date)
            MultipleSelectedDates = Session("AAA")


            If (MultipleSelectedDates.Contains(Calendar1.SelectedDate)) Then
                MultipleSelectedDates.Remove(Calendar1.SelectedDate)
            Else
                MultipleSelectedDates.Add(Calendar1.SelectedDate)        
            End If

            Session("AAA") = MultipleSelectedDates    
            sino = True
        End If
    End Sub

    Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            Session("AAA") = New List(Of Date) 'Solo se ejecuta UNA VEZ
        End If
    End Sub

    Protected Sub btnGetSelectedDate_Click(sender As Object, e As System.EventArgs) Handles btnGetSelectedDate.Click
        Dim MultipleSelectedDates As New List(Of Date)
        MultipleSelectedDates = Session("AAA") ' lo tengo q hacer así pq sino me da error de formato
        MultipleSelectedDates.Sort()
        lblDate.Text = "DIAS"
        For Each dt In MultipleSelectedDates
            lblDate.Text = lblDate.Text + " <br/> " + dt.ToString("dd/MM/yyyy")
        Next
    End Sub
End Class
