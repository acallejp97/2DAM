﻿
Partial Class _Default
    Inherits System.Web.UI.Page

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim aaa As New ServiceReference1.WebServiceSoapClient
        Me.Label1.Text = aaa.FunSuma(Me.TextBox1.Text, Me.TextBox2.Text)
    End Sub
End Class
