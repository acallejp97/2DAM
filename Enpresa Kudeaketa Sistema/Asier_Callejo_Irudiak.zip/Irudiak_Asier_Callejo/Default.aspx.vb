﻿
Partial Class _Default
    Inherits System.Web.UI.Page

    Protected Sub DropDownList1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles Lista.SelectedIndexChanged
        Irudia.ImageUrl = Lista.SelectedItem.Value
        Irudia.AlternateText = "Ez dago " & Lista.SelectedItem.Text & "-rentzako irudirik"
    End Sub
End Class
