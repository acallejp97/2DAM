﻿Imports System.Data.OleDb

Public Class Form1

    Dim conex As New OleDb.OleDbConnection("Provider= Microsoft.ACE.OLEDB.12.0; Data Source= Northwind.mdb") 'Para conectar con la BBDD

    Private Sub btnConectar_Click(sender As Object, e As EventArgs) Handles btnConectar.Click
        Form2.ShowDialog() 'ShowDialog para que no se pueda seleccionar la anterior ventana
    End Sub

    Private Sub btnSalir_Click(sender As Object, e As EventArgs) Handles btnSalir.Click
        MsgBox("Talué xd")
        Me.Close()
    End Sub
End Class
