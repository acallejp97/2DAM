﻿Imports System.Data.OleDb

Public Class Form2
    Dim conex As New OleDb.OleDbConnection("Provider= Microsoft.ACE.OLEDB.12.0; Data Source= Northwind.mdb") 'Para conectar con la BBDD

    Private Sub btnAnnadir_Click(sender As Object, e As EventArgs) Handles btnAnnadir.Click
        Form3.ShowDialog()
    End Sub

    Private Sub btnMostrar_Click(sender As Object, e As EventArgs) Handles btnMostrar.Click
        Dim sentencia As String = "Select * FROM Categories"
        Dim cmd1 As New OleDbCommand(sentencia, conex)
        Dim adaptador1 = New OleDbDataAdapter(cmd1)
        Dim dataSet As New DataSet
        adaptador1.Fill(dataSet)

        Me.DataGridView1.DataSource = dataSet.Tables(0)

    End Sub
End Class