﻿Imports System.Data.OleDb
Public Class Form3
    Dim count As Integer
    Dim conex As New OleDb.OleDbConnection("Provider= Microsoft.ACE.OLEDB.12.0; Data Source= Northwind.mdb") 'Para conectar con la BBDD

    Private Sub Form3_Load(sender As Object, e As EventArgs) Handles MyBase.Load



        conex.Open()
        Try
            If conex.State = ConnectionState.Open Then
                Dim cmd1 As New OleDbCommand("SELECT MAX(CategoryID) FROM Categories", conex) 'Distinct para no repetir valores
                count = cmd1.ExecuteScalar
                lblIDNuevo.Text = count + 1
            End If
        Catch ex As Exception
            MsgBox("Fallito")
        Finally
            If conex.State = ConnectionState.Open Then
                conex.Close()
            End If

        End Try
    End Sub


    Private Sub btnSalir_Click(sender As Object, e As EventArgs) Handles btnSalir.Click
        Me.Close()
    End Sub

    Private Sub btnInsertar_Click(sender As Object, e As EventArgs) Handles btnInsertar.Click
        conex.Open()
        Try
            If conex.State = ConnectionState.Open Then
                lblIDNuevo.Text = count + 1
                Dim cmd2 As New OleDbCommand("INSERT INTO Categories (CategoryID, CategoryName, Description) VALUES ('" & count + 1 & "', '" & tbCategoria.Text.ToString & "', '" & tbDescripcion.Text.ToString & "')", conex)

                cmd2.ExecuteNonQuery()
            End If

        Catch ex As Exception
            MsgBox("FAILED TO execute SQL sentence" & vbNewLine & ex.Message)
        Finally
            MsgBox("Guardado")

            If conex.State = ConnectionState.Open Then
                conex.Close()

            End If
        End Try
        Me.Dispose() 'Cierra y borra las variables

    End Sub


End Class