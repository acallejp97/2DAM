﻿
Partial Class Ejercicio3
    Inherits System.Web.UI.Page

End Class
