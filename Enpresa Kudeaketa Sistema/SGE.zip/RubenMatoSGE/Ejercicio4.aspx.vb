﻿Imports System.Data.OleDb
Imports System.Data

Partial Class Ejercicio4
    Inherits System.Web.UI.Page

    Dim das As DataSet
    Dim conexion As New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=|DataDirectory|\Northwind_Compacta.mdb;Persist Security Info=True")


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim sql1 As String = ("Select productid, productname, unitprice from products")
        Dim adapter1 As New OleDbDataAdapter(sql1, conexion)
        das = New DataSet

        Try
            adapter1.Fill(das, "aaa")
            Me.GridView1.DataSource = das.Tables("aaa")
            DataBind()
            Label5.Text = das.Tables(0).Rows.Count & " filas"
        Catch ex As Exception
            Response.Write("Se ha producido una excepción: " & ex.Message)
        End Try

    End Sub

    Protected Sub Buttoneliminar_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button3.Click

        Dim sql2 As String = "Delete * From products where productid = @id"
        Dim comando As New OleDbCommand(sql2, conexion)
        comando.Parameters.AddWithValue("@id", Me.TextBox3.Text)
        Dim resultado As Integer = Nothing

        Try
            conexion.Open()
            resultado = comando.ExecuteNonQuery
            Label5.Text = resultado.ToString & " borrado"
        Catch ex As Exception
            Label5.Text = ex.Message
        Finally
            conexion.Close()
        End Try
    End Sub

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim sql3 As String = "SELECT COUNT(*) FROM products"
        Dim comando As New OleDbCommand(sql3, conexion)
        Dim resultado As Integer

        Try
            conexion.Open()
            resultado = comando.ExecuteScalar
            Me.Label5.Text = resultado & "filas"
        Catch ex As Exception
            Me.Label5.Text = "Error"
        Finally
            conexion.Close()
        End Try
    End Sub

    Protected Sub Button2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim sql4 As String = "Insert into products (productname,unitprice) values (@name,@price)"
        Dim comando As New OleDbCommand(sql4, conexion)
        comando.Parameters.AddWithValue("@name", Me.TextBox1.Text)
        comando.Parameters.AddWithValue("@price", Me.TextBox2.Text)
        Dim resultado As Integer = Nothing

        Try
            conexion.Open()
            resultado = comando.ExecuteNonQuery
            Label5.Text = resultado.ToString & " añadido"
        Catch ex As Exception
            Label5.Text = ex.Message
        Finally
            conexion.Close()
        End Try
    End Sub
End Class
