﻿
Partial Class Ejercicio5
    Inherits System.Web.UI.Page



    Protected Sub GridView1_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles GridView1.RowDataBound
        Try
            If IsNumeric(e.Row.Cells(4).Text) Then
                If e.Row.Cells(4).Text Mod 2 = 0 Then
                    e.Row.BackColor = Drawing.Color.Coral
                Else
                    e.Row.BackColor = Drawing.Color.Crimson
                End If
            Else
                e.Row.BackColor = Drawing.Color.Firebrick
            End If
        Catch ex As Exception

        End Try
        If e.Row.Cells(4).Text = "PostalCode" Then
            e.Row.BackColor = Drawing.Color.White
        End If
    End Sub

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        Label1.BackColor = Drawing.Color.Coral
        Label2.BackColor = Drawing.Color.Crimson
        Label3.BackColor = Drawing.Color.Firebrick
    End Sub

End Class
