﻿Imports Microsoft.Reporting.WebForms

Partial Class Ejercicio6
    Inherits System.Web.UI.Page

    Protected Sub DropDownList1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles DropDownList1.SelectedIndexChanged
        Dim aaa As New ReportParameter("Pais", Me.DropDownList1.SelectedValue)
        Me.ReportViewer1.LocalReport.SetParameters(aaa)
        Me.ReportViewer1.LocalReport.Refresh()
    End Sub

End Class
