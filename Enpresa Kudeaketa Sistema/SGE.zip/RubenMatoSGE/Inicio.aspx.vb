﻿Partial Class Inicio
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Master.FindControl("Menu1").Visible = False
        Master.FindControl("Label1").Visible = False
    End Sub

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If TextBox1.Text = "Admin" And TextBox2.Text = "123" Then
            Master.FindControl("Menu1").Visible = True
            Master.FindControl("Label1").Visible = True
        Else
            Response.Redirect("Inicio.aspx")
        End If
    End Sub
End Class

