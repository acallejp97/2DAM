import java.io.*;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.Provider;
import java.util.Scanner;

public class EscribirMensaje {

	public static void main(String[] args){
		MessageDigest md;
		try{
			md = MessageDigest.getInstance("MD5");
			
			Scanner entrada = new Scanner(System.in);
			System.out.print("Escribe el mensaje: ");
			String mensaje = entrada.next();
			System.out.print("\nEscribe la ruta del fichero: ");
			String ruta = entrada.next();
			
			byte dataBytes[] = mensaje.getBytes();
			md.update(dataBytes);
			byte resumen[] = md.digest();
			
			escribeFichero(ruta+".txt", mensaje);
			escribeFichero(ruta+"Resumen.txt", new String(resumen));
			System.out.println("Sus datos se han guardado correctamente en el fichero "+ ruta +".txt y en el " + 
					"fichero "+ruta+"Resumen.txt");
		}catch(NoSuchAlgorithmException e){
			System.err.println("Error al cifrar el mensaje.");
			e.printStackTrace();
		}
	}
	
	public static void escribeFichero(String ruta, String mensaje){
        FileWriter fichero = null;
        PrintWriter pw = null;
        try
        {
            fichero = new FileWriter(ruta);
            pw = new PrintWriter(fichero);

            pw.println(mensaje);

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
           try {
	           if (null != fichero) {
	              fichero.close();
	           }
           } catch (Exception e2) {
              e2.printStackTrace();
           }
        }
	}
}
