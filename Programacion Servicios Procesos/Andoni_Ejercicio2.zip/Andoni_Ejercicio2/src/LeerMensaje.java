import java.io.*;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Scanner;

public class LeerMensaje {
	
	public static void main(String[] args) {
		Scanner entrada = new Scanner(System.in);
		System.out.print("Escribe la ruta del fichero: ");
		String ruta_mensaje = entrada.next();
		System.out.print("\nEscribe la ruta del fichero con el resumen: ");
		String ruta_resumen = entrada.next();
		
		String mensaje = leerFichero(ruta_mensaje);
		String resumen_lectura = leerFichero(ruta_resumen);
		
		MessageDigest md;
		try{
			md = MessageDigest.getInstance("MD5");
			byte dataBytes[] = mensaje.getBytes();
			md.update(dataBytes);
			byte resumen[] = md.digest();
			
			if(resumen_lectura.equals(new String(resumen))){
				System.out.println("El texto es aut�ntico");
			}else{
				System.out.println("El texto ha sido modificado");
			}
		}catch(NoSuchAlgorithmException e){
			System.err.println("Error al cifrar el mensaje.");
			e.printStackTrace();
		}
	}

   public static String leerFichero(String ruta) {
	  String mensaje = "";
      File archivo = null;
      FileReader fr = null;
      BufferedReader br = null;

      try {
         archivo = new File (ruta);
         fr = new FileReader (archivo);
         br = new BufferedReader(fr);

         String linea;
         while((linea=br.readLine())!=null)
            mensaje += linea;
      }
      catch(Exception e){
         e.printStackTrace();
      }finally{
         try{                    
            if( null != fr ){   
               fr.close();     
            }                  
         }catch (Exception e2){ 
            e2.printStackTrace();
         }
      }
      
      return mensaje;
   }
		
}
