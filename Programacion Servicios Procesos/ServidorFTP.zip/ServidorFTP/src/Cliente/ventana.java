package Cliente;

import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.JPasswordField;

import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPFile;

import java.awt.event.ActionListener;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JSeparator;
import javax.swing.SwingConstants;

public class ventana extends JFrame {

	FTPClient client = new FTPClient();
	private JPanel contentPane;
	private JTextField tfUsuario;
	private JPasswordField tfClave;
	private JTextField tfServidor;

	private String sFTP;
	private String usuario;
	private String clave;
	private String directorio = "D:\2DAM";

	private final String directorioInicial = "/";
	private String direcSeleccionado = directorioInicial;
	private final String carpetaDestino = "C:\\Users\\PC\\Desktop\\DescargasFTP";

	JList list;

	JButton btnConectar;
	JButton btnSubir;
	JButton btnDescargar;
	JButton btnSalir;
	JButton btnLogout;
	JButton btnEliminarFichero;

	JFileChooser seleccionar;

	String CrearDirectorio = "Asier";

	private int cont = 0;
	private JButton btnEliminarDirectorio;
	private JSeparator separator;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {

					ventana frame = new ventana();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}

		});
	}

	/**
	 * Create the frame.
	 */
	public ventana() {
		setTitle("Cliente basico FTP");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 485, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblNewLabel = new JLabel("Usuario:");
		lblNewLabel.setBounds(23, 28, 46, 14);
		getContentPane().add(lblNewLabel);

		JLabel lblClave = new JLabel("Clave:");
		lblClave.setBounds(23, 70, 46, 14);
		getContentPane().add(lblClave);

		JLabel lblServidoeFtp = new JLabel("Servidor FTP:");
		lblServidoeFtp.setBounds(240, 28, 69, 14);
		getContentPane().add(lblServidoeFtp);

		list = new JList();

		list.setBounds(23, 114, 286, 415);
		getContentPane().add(list);

		btnSubir = new JButton("Subir");
		btnSubir.setEnabled(false);
		btnSubir.setBounds(329, 143, 89, 23);
		getContentPane().add(btnSubir);

		btnDescargar = new JButton("Descargar");
		btnDescargar.setEnabled(false);
		btnDescargar.setBounds(329, 177, 89, 23);
		getContentPane().add(btnDescargar);

		btnLogout = new JButton("Logout");
		btnLogout.setEnabled(false);
		btnLogout.setBounds(329, 245, 89, 23);
		contentPane.add(btnLogout);

		btnConectar = new JButton("Conectar");
		btnConectar.setBounds(240, 66, 178, 23);
		getContentPane().add(btnConectar);

		btnSalir = new JButton("Salir");
		btnSalir.setBounds(329, 211, 89, 23);
		getContentPane().add(btnSalir);

		tfUsuario = new JTextField();
		tfUsuario.setBounds(73, 25, 106, 20);
		getContentPane().add(tfUsuario);
		tfUsuario.setColumns(10);

		tfClave = new JPasswordField();
		tfClave.setBounds(73, 67, 106, 20);
		getContentPane().add(tfClave);
		tfClave.setColumns(10);

		tfServidor = new JTextField();

		tfServidor.setBounds(309, 25, 106, 20);
		getContentPane().add(tfServidor);
		tfServidor.setColumns(10);

		btnEliminarFichero = new JButton("Eliminar fichero");
		btnEliminarFichero.setEnabled(false);
		btnEliminarFichero.setBounds(329, 279, 89, 23);
		contentPane.add(btnEliminarFichero);

		JButton btnCrearDirectorio = new JButton("Crear directorio");
		btnCrearDirectorio.setEnabled(false);
		btnCrearDirectorio.setBounds(329, 351, 89, 23);
		contentPane.add(btnCrearDirectorio);

		btnEliminarDirectorio = new JButton("Eliminar directorio");
		btnEliminarDirectorio.setEnabled(false);
		btnEliminarDirectorio.setBounds(329, 385, 89, 23);
		contentPane.add(btnEliminarDirectorio);

		separator = new JSeparator();
		separator.setBounds(319, 313, 110, 9);
		contentPane.add(separator);

		JLabel lblExtra = new JLabel("Extra");
		lblExtra.setHorizontalAlignment(SwingConstants.CENTER);
		lblExtra.setBounds(351, 326, 46, 14);
		contentPane.add(lblExtra);

		// ActionListeners
		///////////////////////////////////////////////////////////////////////////////
		// BorrarDirectorio
		btnEliminarDirectorio.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				JOptionPane.showMessageDialog(null, "Funcion no disponible");

			}
		});

		// CrearDirectorio
		btnCrearDirectorio.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				boolean login = true;
				try {
					login = client.makeDirectory(client.printWorkingDirectory() + "/" + CrearDirectorio);
					if (login)
						JOptionPane.showMessageDialog(null, "Directorio creado");

					FTPFile[] ficheros = client.listFiles();
					llenarLista(ficheros, directorioInicial);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					JOptionPane.showMessageDialog(null, "Error al crear directorio");
				}
			}
		});

		// BorrarFichero
		btnEliminarFichero.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				String filename = list.getSelectedValue().toString();
				try {
					// En caso de que sea un fichero har� una cosa y sino otra
					if (list.getSelectedValue().toString().startsWith("(DIR)")) {
					} else {
						client.deleteFile(filename);
					} // Metodo predefinido para borrar ficheros
					JOptionPane.showMessageDialog(null, "Borrado " + filename);

					// este metodo lo uso para volver a llenar la lista una vez que hago una accion
					// en ella,
					// ya sea subir, borrar, o simplemente hacer logoff. Es lo mismo todo el rato
					FTPFile[] ficheros = client.listFiles();
					llenarLista(ficheros, directorioInicial);

				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});

		// Conectar
		btnConectar.addActionListener(new ActionListener() {
			@SuppressWarnings("deprecation")
			public void actionPerformed(ActionEvent arg0) {
				// Cogemos el usuario, servidor y contrase�a en caso de que haya
				sFTP = tfServidor.getText();
				usuario = tfUsuario.getText();
				clave = tfClave.getText();

				try {
					// Conectamos al servidor
					client.connect(sFTP);
					// hacemos login
					boolean login = client.login(usuario, clave);
					if (login) {
						// si es true te carga todo el programa
						JOptionPane.showMessageDialog(null, "Conexion realizada con exito");
						btnSubir.setEnabled(true);
						btnDescargar.setEnabled(true);
						btnLogout.setEnabled(true);
						btnCrearDirectorio.setEnabled(true);

						FTPFile[] ficheros = client.listFiles();
						llenarLista(ficheros, directorioInicial);
					} else // en caso de false te saca este error
						JOptionPane.showMessageDialog(null, "Usuario o contrase�a incorrectos");

				} catch (IOException e) {
					JOptionPane.showMessageDialog(null, "Error al realizar la conexion");
				}

			}
		});

		// Salir
		btnSalir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
			}
		});

		// Logout
		btnLogout.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					client.logout();
					client.disconnect();
					btnDescargar.setEnabled(false);
					btnSubir.setEnabled(false);
					btnLogout.setEnabled(false);
					btnEliminarFichero.setEnabled(false);
					btnCrearDirectorio.setEnabled(false);

					list.setListData(new String[0]);

				} catch (IOException ex) {
					JOptionPane.showMessageDialog(null, "No se ha logueado");
				}
			}
		});

		// Descargar
		btnDescargar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				try {
					// Para descargar un archivo seleccionamos un archivo de la lista y despues
					// habiendo predefinido una ruta nos lo descarga aho
					String fichDestino = carpetaDestino + list.getSelectedValue().toString();
					client.setFileType(FTP.BINARY_FILE_TYPE);
					BufferedOutputStream out = new BufferedOutputStream(new FileOutputStream(fichDestino));
					client.retrieveFile(list.getSelectedValue().toString(), out);
					JOptionPane.showMessageDialog(null, "Descargado ");
					out.close();// Importante, sino no te descarga
					FTPFile[] ficheros = client.listFiles();
					llenarLista(ficheros, directorioInicial);
				} catch (IOException e) {
					JOptionPane.showMessageDialog(null, "Error");
				}

			}
		});

		// Subir
		btnSubir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				// seleccionamos un archivo y lo subimos
				seleccionar = new JFileChooser();
				seleccionar.setFileSelectionMode(JFileChooser.FILES_ONLY);
				seleccionar.setDialogTitle("Seleccionar el fichero");
				int retorno = seleccionar.showDialog(seleccionar, "Subir");

				if (retorno == JFileChooser.APPROVE_OPTION) {
					File fichero = seleccionar.getSelectedFile();
					String nombreRuta = fichero.getAbsolutePath();
					String nombre = fichero.getName();
					BufferedInputStream out;
					try {
						client.setFileType(FTP.BINARY_FILE_TYPE);
						out = new BufferedInputStream(new FileInputStream(nombreRuta));
						client.storeFile(nombre, out);
						JOptionPane.showMessageDialog(null, "Subido");
						out.close();
						FTPFile[] ficheros = client.listFiles();
						llenarLista(ficheros, directorioInicial);
					} catch (FileNotFoundException ex) {
						JOptionPane.showMessageDialog(null, "Error");
					} catch (IOException e) {
						JOptionPane.showMessageDialog(null, "Error");
					}

				}

			}
		});

		//////////////////////////// KeyListener
		tfServidor.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent arg0) {
				if (arg0.getKeyCode() == KeyEvent.VK_ENTER)
					btnConectar.doClick();
			}
		});

		tfUsuario.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent arg0) {
				if (arg0.getKeyCode() == KeyEvent.VK_ENTER)
					btnConectar.doClick();
			}
		});

		tfClave.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent arg0) {
				if (arg0.getKeyCode() == KeyEvent.VK_ENTER)
					btnConectar.doClick();
			}
		});

		list.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				try {
					if (e.getClickCount() == 2) {
						dobleClick();
					}
					if (list.getSelectedValue().toString().startsWith("(DIR)")) {
						btnEliminarDirectorio.setEnabled(true);

						btnEliminarFichero.setEnabled(false);
					} else if (!list.getSelectedValue().toString().startsWith("(DIR)")) {
						btnEliminarDirectorio.setEnabled(false);

						btnEliminarFichero.setEnabled(true);
					} else if (!list.getSelectedValue().toString().isEmpty()) {
						btnEliminarDirectorio.setEnabled(false);

						btnEliminarFichero.setEnabled(false);
					}
				} catch (Exception exc) {

				}
			}
		});

		///////////////////////////////////////////////////////////////////////////////////////////

	}

	// Llenar la lista
	// te detecta cuantos archivos hay y te los muestra en la lista
	private void llenarLista(FTPFile[] ficheros, String directorioActual) throws IOException {
		DefaultListModel<String> modelo = new DefaultListModel<>();
		modelo.addElement(directorioActual);
		for (int i = 0; i < ficheros.length; i++) {
			if (!(ficheros[i].getName()).equals(".") && !(ficheros[i].getName()).equals("..")) {
				String f = ficheros[i].getName();
				if (ficheros[i].isDirectory())
					f = "(DIR) " + f;
				modelo.addElement(f);
			}
		}
		list.setModel(modelo);
	}

	// Doble click
	public void dobleClick() {
		try {

			if (list.getSelectedValue().equals(list.getModel().getElementAt(0))) {
				client.changeToParentDirectory();
				direcSeleccionado = client.printWorkingDirectory();
				client.changeWorkingDirectory(direcSeleccionado);
			} else {

				if (list.getSelectedValue().toString().startsWith("(DIR)")) {// El primer elemento es la raiz

					direcSeleccionado = list.getSelectedValue().toString().replace("(DIR) ", "");
					client.changeWorkingDirectory(direcSeleccionado);
				} else {
					direcSeleccionado = list.getSelectedValue().toString();
				}
			}
			FTPFile[] ficheros = client.listFiles();
			llenarLista(ficheros, direcSeleccionado);

		} catch (IOException e) {
			JOptionPane.showMessageDialog(null, "Error");
		}
	}
}
